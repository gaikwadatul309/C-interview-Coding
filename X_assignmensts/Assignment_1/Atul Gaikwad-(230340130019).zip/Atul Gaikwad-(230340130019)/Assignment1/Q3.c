
//C program to find out Biggest of Three input numbers.
#include<stdio.h>
int main(){
	int a=10,b=22,c=7;
	if((a>b) && (a>c)){
		printf("a is biggest of all");
		}else if((b>a) && (b>c)){
		     printf("b is Biggest");
		}else{
		     printf("C is biggest");
		}


}
